# Save The Princess
Um jogo desenvolvido com a Engine ASCII para o tutorial de como usar a Engine.

Assista o minicurso em https://www.youtube.com/playlist?list=PL9zfef1hSFehpKd9W5iY86MrWlQqW7NCN .

