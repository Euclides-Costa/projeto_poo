#include <iostream>
#include <string>

#include "Game.hpp"


int main()
{
	Game::run();
	
	return 0;
}
